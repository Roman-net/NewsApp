﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace NewsApp.Data.Migrations
{
    public partial class User_Table_Created : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
